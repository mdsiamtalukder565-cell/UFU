extends RigidBody3D
## The football: RigidBody3D with bounce, damping and a blob shadow.

const RADIUS := 0.4

var shadow: MeshInstance3D


func _ready() -> void:
	mass = 0.43
	can_sleep = false
	continuous_cd = true
	linear_damp = 0.55
	angular_damp = 1.2
	collision_layer = 4   # ball layer
	collision_mask = 1    # collides with world only (athletes use scripted touches)

	var pm := PhysicsMaterial.new()
	pm.bounce = 0.55
	pm.friction = 0.7
	physics_material_override = pm

	var col := CollisionShape3D.new()
	var sph := SphereShape3D.new()
	sph.radius = RADIUS
	col.shape = sph
	add_child(col)

	var mesh := SphereMesh.new()
	mesh.radius = RADIUS
	mesh.height = RADIUS * 2.0
	mesh.radial_segments = 16
	mesh.rings = 8
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_texture = _make_texture()
	mat.roughness = 0.6
	mi.material_override = mat
	add_child(mi)

	shadow = MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.45
	cyl.bottom_radius = 0.45
	cyl.height = 0.01
	cyl.radial_segments = 12
	cyl.rings = 1
	var sm := StandardMaterial3D.new()
	sm.albedo_color = Color(0, 0, 0, 0.4)
	sm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	shadow.mesh = cyl
	shadow.material_override = sm
	shadow.top_level = true
	add_child(shadow)


func _make_texture() -> ImageTexture:
	var img := Image.create(128, 64, false, Image.FORMAT_RGB8)
	img.fill(Color(0.96, 0.96, 0.96))
	var dark := Color(0.08, 0.08, 0.1)
	for i in range(8):
		for j in range(3):
			img.fill_rect(Rect2i(i * 16 + 3, 8 + j * 18, 10, 10), dark)
	return ImageTexture.create_from_image(img)


func _process(_delta: float) -> void:
	var p := global_position
	shadow.global_position = Vector3(p.x, 0.05, p.z)
	var s := clampf(1.0 - p.y * 0.12, 0.35, 1.0)
	shadow.scale = Vector3(s, 1.0, s)


func reset_to(pos: Vector3) -> void:
	global_position = pos
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO


func flat_speed() -> float:
	return Vector2(linear_velocity.x, linear_velocity.z).length()
