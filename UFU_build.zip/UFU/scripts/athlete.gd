extends CharacterBody3D
## Shared humanoid body, animation and movement helpers (player, opponents, keepers).

const GRAVITY := 22.0

var active := false
var facing := Vector3(0.0, 0.0, -1.0)
var touch_cd := 0.0
var kick_anim := 0.0
var anim_t := 0.0

var visual: Node3D
var leg_l: Node3D
var leg_r: Node3D
var arm_l: Node3D
var arm_r: Node3D


func build_body(shirt: Color, shorts: Color, skin: Color) -> void:
	collision_layer = 2
	collision_mask = 3

	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	col.shape = cap
	col.position = Vector3(0.0, 0.9, 0.0)
	add_child(col)

	visual = Node3D.new()
	add_child(visual)

	var torso := CapsuleMesh.new()
	torso.radius = 0.26
	torso.height = 0.85
	torso.radial_segments = 8
	torso.rings = 3
	_add_mesh(visual, torso, Vector3(0.0, 1.15, 0.0), shirt)

	var hips := BoxMesh.new()
	hips.size = Vector3(0.46, 0.3, 0.32)
	_add_mesh(visual, hips, Vector3(0.0, 0.85, 0.0), shorts)

	var head := SphereMesh.new()
	head.radius = 0.18
	head.height = 0.36
	head.radial_segments = 10
	head.rings = 5
	_add_mesh(visual, head, Vector3(0.0, 1.72, 0.0), skin)

	var visor := BoxMesh.new()
	visor.size = Vector3(0.26, 0.07, 0.08)
	_add_mesh(visual, visor, Vector3(0.0, 1.74, -0.15), Color(0.1, 0.1, 0.12))

	leg_l = _limb(Vector3(-0.12, 0.82, 0.0), Vector3(0.17, 0.82, 0.19), shirt)
	leg_r = _limb(Vector3(0.12, 0.82, 0.0), Vector3(0.17, 0.82, 0.19), shirt)
	arm_l = _limb(Vector3(-0.36, 1.45, 0.0), Vector3(0.13, 0.55, 0.13), skin)
	arm_r = _limb(Vector3(0.36, 1.45, 0.0), Vector3(0.13, 0.55, 0.13), skin)

	# blob shadow
	var sh := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.55
	cyl.bottom_radius = 0.55
	cyl.height = 0.01
	cyl.radial_segments = 12
	cyl.rings = 1
	var sm := StandardMaterial3D.new()
	sm.albedo_color = Color(0.0, 0.0, 0.0, 0.35)
	sm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sh.mesh = cyl
	sh.material_override = sm
	sh.position = Vector3(0.0, 0.04, 0.0)
	add_child(sh)


func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.9
	return m


func _add_mesh(parent: Node3D, mesh: Mesh, pos: Vector3, c: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = _mat(c)
	mi.position = pos
	parent.add_child(mi)
	return mi


func _limb(pos: Vector3, size: Vector3, c: Color) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = pos
	visual.add_child(pivot)
	var bm := BoxMesh.new()
	bm.size = size
	_add_mesh(pivot, bm, Vector3(0.0, -size.y * 0.5, 0.0), c)
	return pivot


func reset_to(pos: Vector3, face: Vector3) -> void:
	global_position = pos + Vector3(0.0, 0.05, 0.0)
	velocity = Vector3.ZERO
	facing = face.normalized()
	if visual != null:
		visual.rotation.y = atan2(-facing.x, -facing.z)
		visual.rotation.z = 0.0
	touch_cd = 0.0
	kick_anim = 0.0


func steer_facing(dir: Vector3, delta: float) -> void:
	if dir.length() < 0.01:
		return
	var nf := facing.lerp(dir.normalized(), clampf(12.0 * delta, 0.0, 1.0))
	if nf.length() > 0.01:
		facing = nf.normalized()


func move_athlete(delta: float) -> void:
	if is_on_floor():
		velocity.y = -0.5
	else:
		velocity.y -= GRAVITY * delta
	move_and_slide()


func animate(delta: float, hspeed: float) -> void:
	var target_yaw := atan2(-facing.x, -facing.z)
	visual.rotation.y = lerp_angle(visual.rotation.y, target_yaw, clampf(14.0 * delta, 0.0, 1.0))
	var k := clampf(hspeed / 9.0, 0.0, 1.0)
	anim_t += delta * (4.0 + hspeed * 1.6)
	var swing := sin(anim_t) * 0.95 * k
	leg_l.rotation.x = swing
	leg_r.rotation.x = -swing
	arm_l.rotation.x = -swing * 0.8
	arm_r.rotation.x = swing * 0.8
	visual.position.y = absf(sin(anim_t)) * 0.06 * k
	if kick_anim > 0.0:
		kick_anim = maxf(0.0, kick_anim - delta)
		var progress := 1.0 - kick_anim / 0.25
		leg_r.rotation.x = sin(progress * PI) * 1.4
