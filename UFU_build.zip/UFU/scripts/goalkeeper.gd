extends "res://scripts/athlete.gd"
## Goalkeeper AI: tracks the ball along the goal line, predicts shots, dives and parries.

var ball: RigidBody3D
var goal_sign := -1.0      # -1: guards the goal at z = -50, +1: goal at z = +50
var save_chance := 0.65
var keeper_speed := 6.5
var dive_t := 0.0
var dive_dir := 0.0
var dive_cd := 0.0
var decided := false


func setup(sign_z: float, shirt: Color, chance: float) -> void:
	goal_sign = sign_z
	save_chance = chance
	build_body(shirt, Color(0.1, 0.1, 0.12), Color(0.8, 0.6, 0.45))


func _physics_process(delta: float) -> void:
	dive_cd = maxf(0.0, dive_cd - delta)
	var hv := Vector3(velocity.x, 0.0, velocity.z)

	if not active or ball == null:
		hv = hv.move_toward(Vector3.ZERO, 30.0 * delta)
		velocity.x = hv.x
		velocity.z = hv.z
		move_athlete(delta)
		animate(delta, hv.length())
		return

	var bp := ball.global_position
	var bv := ball.linear_velocity
	var goal_z := goal_sign * 50.0
	var ball_dist := absf(bp.z - goal_z)
	var out := lerpf(1.0, 3.5, clampf(1.0 - ball_dist / 25.0, 0.0, 1.0))
	var line_z := goal_sign * (50.0 - out)

	var px := clampf(bp.x * 0.22, -3.0, 3.0)
	var t_hit := 99.0
	if bv.z * goal_sign > 2.0:
		var t := (line_z - bp.z) / bv.z
		if t > 0.0 and t < 2.0:
			t_hit = t
			px = bp.x + bv.x * t

	# decide to dive
	if dive_t <= 0.0 and dive_cd <= 0.0 and t_hit < 0.55 and bv.length() > 10.0:
		if absf(px - global_position.x) > 1.2 and absf(px) < 5.0:
			dive_t = 0.5
			dive_dir = signf(px - global_position.x)
			dive_cd = 1.4

	if dive_t > 0.0:
		dive_t -= delta
		hv.x = dive_dir * 9.0
		hv.z = move_toward(hv.z, 0.0, 30.0 * delta)
	else:
		var tx := clampf(px, -3.4, 3.4)
		var vx := clampf((tx - global_position.x) * 8.0, -keeper_speed, keeper_speed)
		hv.x = move_toward(hv.x, vx, 40.0 * delta)
		var vz := clampf((line_z - global_position.z) * 5.0, -keeper_speed, keeper_speed)
		hv.z = move_toward(hv.z, vz, 40.0 * delta)

	velocity.x = hv.x
	velocity.z = hv.z

	# face the ball
	var to_b := Vector3(bp.x - global_position.x, 0.0, bp.z - global_position.z)
	if to_b.length() > 0.5:
		facing = to_b.normalized()

	# save attempt
	var bflat := Vector2(bp.x - global_position.x, bp.z - global_position.z).length()
	var reach := 2.3 if dive_t > 0.0 else 1.5
	if bflat < reach and bp.y < 2.7:
		if not decided:
			decided = true
			if randf() < save_chance:
				_parry()
	elif bflat > reach + 1.5:
		decided = false

	move_athlete(delta)
	global_position.x = clampf(global_position.x, -3.8, 3.8)
	animate(delta, hv.length())

	# dive tilt (sign flips depending on which way the keeper is facing)
	var s := 1.0 if facing.z <= 0.0 else -1.0
	var tilt := 0.0
	if dive_t > 0.0:
		tilt = -dive_dir * 1.2 * s
	visual.rotation.z = lerpf(visual.rotation.z, tilt, clampf(15.0 * delta, 0.0, 1.0))


func _parry() -> void:
	var dir := Vector3(randf_range(-0.9, 0.9), 0.0, -goal_sign).normalized()
	ball.linear_velocity = dir * randf_range(9.0, 14.0) + Vector3(0.0, randf_range(1.5, 4.0), 0.0)
	kick_anim = 0.3
