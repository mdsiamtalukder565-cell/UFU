extends Node3D
## Builds the whole stadium + match in code and runs the game flow.

const PlayerScript = preload("res://scripts/player.gd")
const OpponentScript = preload("res://scripts/opponent.gd")
const KeeperScript = preload("res://scripts/goalkeeper.gd")
const BallScript = preload("res://scripts/ball.gd")
const ControlsScript = preload("res://scripts/touch_controls.gd")
const HudScript = preload("res://scripts/hud.gd")

const HALF_X := 32.0
const HALF_Z := 50.0
const GOAL_HALF := 4.2
const GOAL_H := 2.6
const GOAL_DEPTH := 2.6
const ROWS := 9
const TEAM_BLUE := "NOVA"
const TEAM_RED := "EMBER"
const CAM_H := [7.5, 10.0, 13.0]
const CAM_BACK := [10.0, 13.5, 17.0]

enum State { COUNTDOWN, PLAYING, GOAL, FULLTIME }

var state: State = State.COUNTDOWN
var state_timer := 0.0
var score_blue := 0
var score_red := 0
var match_length := 180.0
var time_left := 180.0
var training := false

var player: PlayerScript
var ball: BallScript
var keeper_red: KeeperScript    # guards z = -50 (the goal you attack)
var keeper_blue: KeeperScript   # guards z = +50 (your goal)
var opponents: Array = []
var hud: HudScript
var controls: ControlsScript
var cam: Camera3D

var _cam_focus := Vector3(0, 0, 8)
var _ball_prev_z := 0.0
var _out_timer := 0.0
var _chaser_timer := 0.0


func _ready() -> void:
	randomize()
	training = (Game.mode == "training")
	match_length = 300.0 if training else float(Game.match_minutes) * 60.0
	time_left = match_length

	_build_environment()
	_build_pitch()
	_build_goal(-1.0)
	_build_goal(1.0)
	_build_walls()
	_build_stadium()
	_build_ui()
	_spawn_ball()
	_spawn_teams()
	_build_camera()
	_start_kickoff()


# =====================================================================
#  WORLD BUILDING
# =====================================================================
func _mat(c: Color, alpha := 1.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(c.r, c.g, c.b, alpha)
	m.roughness = 0.95
	if alpha < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return m


func _box_body(size: Vector3, pos: Vector3, c: Color, visible_mesh := true, alpha := 1.0) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	col.shape = shape
	body.add_child(col)
	if visible_mesh:
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = size
		mi.mesh = bm
		mi.material_override = _mat(c, alpha)
		body.add_child(mi)
	add_child(body)
	return body


func _deco_box(size: Vector3, pos: Vector3, c: Color) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _mat(c)
	mi.position = pos
	add_child(mi)


func _build_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.45, 0.68, 0.95)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.85, 0.88, 1.0)
	env.ambient_light_energy = 0.65
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55.0, -30.0, 0.0)
	sun.light_energy = 0.9
	sun.shadow_enabled = false
	add_child(sun)


func _build_pitch() -> void:
	# big outer grass
	var outer := MeshInstance3D.new()
	var om := PlaneMesh.new()
	om.size = Vector2(240.0, 240.0)
	outer.mesh = om
	outer.position = Vector3(0.0, -0.03, 0.0)
	var omat := StandardMaterial3D.new()
	omat.albedo_color = Color(0.12, 0.38, 0.16)
	omat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	outer.material_override = omat
	add_child(outer)

	# marked pitch
	var pitch := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(HALF_X * 2.0, HALF_Z * 2.0)
	pitch.mesh = pm
	var pmat := StandardMaterial3D.new()
	pmat.albedo_texture = _make_pitch_texture()
	pmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	pmat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	pitch.material_override = pmat
	add_child(pitch)

	# ground collider
	var ground := StaticBody3D.new()
	var gc := CollisionShape3D.new()
	var gs := BoxShape3D.new()
	gs.size = Vector3(240.0, 1.0, 240.0)
	gc.shape = gs
	gc.position = Vector3(0.0, -0.5, 0.0)
	ground.add_child(gc)
	add_child(ground)


func _make_pitch_texture() -> ImageTexture:
	var w := 640
	var h := 1000
	var img := Image.create(w, h, false, Image.FORMAT_RGB8)
	var light := Color(0.18, 0.55, 0.22)
	var dark := Color(0.15, 0.48, 0.19)
	for i in range(10):
		img.fill_rect(Rect2i(0, i * 100, w, 100), light if i % 2 == 0 else dark)

	# boundary
	_line(img, -31.9, -49.9, 31.9, -49.9)
	_line(img, -31.9, 49.9, 31.9, 49.9)
	_line(img, -31.9, -49.9, -31.9, 49.9)
	_line(img, 31.9, -49.9, 31.9, 49.9)
	# halfway line + centre circle
	_line(img, -31.9, 0.0, 31.9, 0.0)
	_circle(img, 0.0, 0.0, 9.0, 0.0, TAU)
	_dot(img, 0.0, 0.0)
	# penalty areas, six-yard boxes, spots, arcs
	for s in [-1.0, 1.0]:
		var z_edge: float = s * 50.0
		var z_pen: float = s * 34.0
		var z_six: float = s * 44.5
		_line(img, -20.0, z_pen, 20.0, z_pen)
		_line(img, -20.0, z_edge, -20.0, z_pen)
		_line(img, 20.0, z_edge, 20.0, z_pen)
		_line(img, -9.0, z_six, 9.0, z_six)
		_line(img, -9.0, z_edge, -9.0, z_six)
		_line(img, 9.0, z_edge, 9.0, z_six)
		_dot(img, 0.0, s * 39.0)
		if s < 0.0:
			_circle(img, 0.0, -39.0, 9.0, 0.589, 2.553)
		else:
			_circle(img, 0.0, 39.0, 9.0, 3.731, 5.694)

	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


func _px(x: float) -> int:
	return clampi(int((x + HALF_X) * 10.0), 0, 639)


func _pz(z: float) -> int:
	return clampi(int((z + HALF_Z) * 10.0), 0, 999)


func _line(img: Image, x0: float, z0: float, x1: float, z1: float) -> void:
	var a := _px(minf(x0, x1)) - 1
	var b := _pz(minf(z0, z1)) - 1
	var c := _px(maxf(x0, x1)) + 2
	var d := _pz(maxf(z0, z1)) + 2
	a = clampi(a, 0, 639)
	b = clampi(b, 0, 999)
	c = clampi(c, 0, 640)
	d = clampi(d, 0, 1000)
	img.fill_rect(Rect2i(a, b, c - a, d - b), Color.WHITE)


func _dot(img: Image, x: float, z: float) -> void:
	img.fill_rect(Rect2i(_px(x) - 3, _pz(z) - 3, 7, 7), Color.WHITE)


func _circle(img: Image, cx: float, cz: float, r: float, a0: float, a1: float) -> void:
	var steps := 260
	for i in range(steps + 1):
		var a := a0 + (a1 - a0) * float(i) / float(steps)
		var x := cx + cos(a) * r
		var z := cz + sin(a) * r
		if absf(x) < HALF_X and absf(z) < HALF_Z:
			img.fill_rect(Rect2i(_px(x) - 1, _pz(z) - 1, 3, 3), Color.WHITE)


func _build_goal(s: float) -> void:
	var white := Color(0.97, 0.97, 0.97)
	var gz := s * HALF_Z
	# posts + crossbar (solid)
	for sx in [-1.0, 1.0]:
		_box_body(Vector3(0.2, GOAL_H, 0.2), Vector3(float(sx) * GOAL_HALF, GOAL_H * 0.5, gz), white)
	_box_body(Vector3(GOAL_HALF * 2.0 + 0.2, 0.2, 0.2), Vector3(0.0, GOAL_H - 0.1, gz), white)
	# nets: back and sides collide, top is visual only
	var net_z := gz + s * (GOAL_DEPTH * 0.5)
	_box_body(Vector3(GOAL_HALF * 2.0, GOAL_H, 0.1), Vector3(0.0, GOAL_H * 0.5, gz + s * GOAL_DEPTH), white, true, 0.2)
	for sx2 in [-1.0, 1.0]:
		_box_body(Vector3(0.1, GOAL_H, GOAL_DEPTH), Vector3(float(sx2) * GOAL_HALF, GOAL_H * 0.5, net_z), white, true, 0.2)
	var top := MeshInstance3D.new()
	var tm := BoxMesh.new()
	tm.size = Vector3(GOAL_HALF * 2.0, 0.05, GOAL_DEPTH)
	top.mesh = tm
	top.material_override = _mat(white, 0.2)
	top.position = Vector3(0.0, GOAL_H, net_z)
	add_child(top)


func _build_walls() -> void:
	var board := Color(0.08, 0.12, 0.30)
	# invisible collision walls (tall so the ball never leaves)
	_box_body(Vector3(1.0, 40.0, 120.0), Vector3(HALF_X + 3.0, 20.0, 0.0), board, false)
	_box_body(Vector3(1.0, 40.0, 120.0), Vector3(-HALF_X - 3.0, 20.0, 0.0), board, false)
	_box_body(Vector3(80.0, 40.0, 1.0), Vector3(0.0, 20.0, HALF_Z + 4.5), board, false)
	_box_body(Vector3(80.0, 40.0, 1.0), Vector3(0.0, 20.0, -HALF_Z - 4.5), board, false)
	# visible low advertising boards
	_deco_box(Vector3(0.4, 1.1, 108.0), Vector3(HALF_X + 2.3, 0.55, 0.0), board)
	_deco_box(Vector3(0.4, 1.1, 108.0), Vector3(-HALF_X - 2.3, 0.55, 0.0), board)
	_deco_box(Vector3(69.0, 1.1, 0.4), Vector3(0.0, 0.55, HALF_Z + 3.8), board)
	_deco_box(Vector3(69.0, 1.1, 0.4), Vector3(0.0, 0.55, -HALF_Z - 3.8), board)


func _build_stadium() -> void:
	var step_mat := _mat(Color(0.50, 0.52, 0.58))
	var palette := [
		Color(0.9, 0.1, 0.1), Color(0.1, 0.35, 0.9), Color(1, 1, 1),
		Color(1.0, 0.85, 0.1), Color(0.15, 0.15, 0.2), Color(0.2, 0.7, 0.3),
		Color(0.95, 0.5, 0.1),
	]
	var xforms: Array[Transform3D] = []
	var cols: Array[Color] = []
	_add_stand(0.0, 35.5, 112.0, xforms, cols, palette, step_mat)
	_add_stand(180.0, 35.5, 112.0, xforms, cols, palette, step_mat)
	_add_stand(90.0, 55.0, 70.0, xforms, cols, palette, step_mat)
	_add_stand(-90.0, 55.0, 70.0, xforms, cols, palette, step_mat)

	# whole crowd = ONE MultiMesh (one draw call)
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	var sm := BoxMesh.new()
	sm.size = Vector3(0.55, 0.9, 0.45)
	mm.mesh = sm
	mm.instance_count = xforms.size()
	for i in range(xforms.size()):
		mm.set_instance_transform(i, xforms[i])
		mm.set_instance_color(i, cols[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	var cm := StandardMaterial3D.new()
	cm.vertex_color_use_as_albedo = true
	cm.roughness = 1.0
	mmi.material_override = cm
	add_child(mmi)

	# floodlight poles
	for cx in [-44.0, 44.0]:
		for cz in [-64.0, 64.0]:
			var pole := MeshInstance3D.new()
			var cyl := CylinderMesh.new()
			cyl.top_radius = 0.35
			cyl.bottom_radius = 0.5
			cyl.height = 24.0
			cyl.radial_segments = 8
			cyl.rings = 1
			pole.mesh = cyl
			pole.material_override = _mat(Color(0.6, 0.6, 0.65))
			pole.position = Vector3(float(cx), 12.0, float(cz))
			add_child(pole)
			var lamp := MeshInstance3D.new()
			var lm := BoxMesh.new()
			lm.size = Vector3(6.0, 2.0, 1.0)
			lamp.mesh = lm
			var lmat := _mat(Color(1.0, 0.98, 0.85))
			lmat.emission_enabled = true
			lmat.emission = Color(1.0, 0.95, 0.7)
			lamp.material_override = lmat
			lamp.position = Vector3(float(cx), 24.5, float(cz))
			add_child(lamp)


func _add_stand(yaw_deg: float, start: float, length: float, xforms: Array[Transform3D],
		cols: Array[Color], palette: Array, step_mat: Material) -> void:
	var bs := Basis(Vector3.UP, deg_to_rad(yaw_deg))
	for r in range(ROWS):
		var h := 0.8 + float(r) * 1.0
		var x := start + float(r) * 1.5 + 0.75
		var step := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(1.5, h, length)
		step.mesh = bm
		step.material_override = step_mat
		step.position = bs * Vector3(x, h * 0.5, 0.0)
		step.rotation.y = deg_to_rad(yaw_deg)
		add_child(step)
		var count := int(length / 1.25)
		for k in range(count):
			if randf() < 0.1:
				continue
			var z := -length * 0.5 + (float(k) + 0.5) * 1.25
			var p := bs * Vector3(x, h + 0.45, z)
			xforms.append(Transform3D(bs, p))
			cols.append(palette[randi() % palette.size()])


# =====================================================================
#  UI / ENTITIES / CAMERA
# =====================================================================
func _build_ui() -> void:
	var cl := CanvasLayer.new()
	cl.layer = 5
	add_child(cl)
	controls = ControlsScript.new()
	cl.add_child(controls)

	hud = HudScript.new()
	add_child(hud)
	hud.pause_pressed.connect(_on_pause)
	hud.resume_pressed.connect(_on_resume)
	hud.restart_pressed.connect(_on_restart)
	hud.menu_pressed.connect(_on_menu)


func _spawn_ball() -> void:
	ball = BallScript.new()
	ball.position = Vector3(0.0, 0.5, 0.0)
	add_child(ball)


func _spawn_teams() -> void:
	player = PlayerScript.new()
	player.setup()
	player.ball = ball
	player.controls = controls
	player.position = Vector3(0.0, 0.05, 6.0)
	add_child(player)

	var speeds := [5.2, 6.1, 6.9]
	var powers := [0.85, 1.0, 1.12]
	var chances := [0.45, 0.62, 0.78]
	var opp_speed: float = speeds[Game.difficulty]
	var opp_power: float = powers[Game.difficulty]
	var red_chance: float = chances[Game.difficulty]
	var homes: Array = [Vector3(-12, 0, -30), Vector3(12, 0, -30), Vector3(-7, 0, -14), Vector3(7, 0, -14)]
	if training:
		homes = [Vector3(-7, 0, -22), Vector3(7, 0, -22)]
		opp_speed *= 0.65
		opp_power *= 0.8
		red_chance = 0.45

	var skins := [Color(0.75, 0.55, 0.4), Color(0.55, 0.38, 0.28), Color(0.9, 0.72, 0.58), Color(0.4, 0.28, 0.2)]
	var idx := 0
	for h in homes:
		var o: OpponentScript = OpponentScript.new()
		o.setup(Color(0.9, 0.15, 0.15), skins[idx % skins.size()], h, opp_speed, opp_power)
		o.ball = ball
		o.position = h + Vector3(0.0, 0.05, 0.0)
		add_child(o)
		opponents.append(o)
		idx += 1

	keeper_red = KeeperScript.new()
	keeper_red.setup(-1.0, Color(1.0, 0.8, 0.1), red_chance)
	keeper_red.ball = ball
	keeper_red.position = Vector3(0.0, 0.05, -48.8)
	add_child(keeper_red)

	keeper_blue = KeeperScript.new()
	keeper_blue.setup(1.0, Color(0.2, 0.85, 0.6), 0.65)
	keeper_blue.ball = ball
	keeper_blue.position = Vector3(0.0, 0.05, 48.8)
	add_child(keeper_blue)


func _build_camera() -> void:
	cam = Camera3D.new()
	cam.fov = 62.0
	cam.near = 0.2
	cam.far = 220.0
	add_child(cam)
	cam.make_current()
	_cam_focus = player.global_position


func _process(delta: float) -> void:
	if player == null or ball == null or cam == null:
		return
	var focus := player.global_position.lerp(ball.global_position, 0.3)
	focus.x = clampf(focus.x, -26.0, 26.0)
	focus.z = clampf(focus.z, -44.0, 42.0)
	focus.y = 0.0
	_cam_focus = _cam_focus.lerp(focus, 1.0 - exp(-5.0 * delta))
	var h: float = CAM_H[Game.camera_zoom]
	var back: float = CAM_BACK[Game.camera_zoom]
	cam.global_position = _cam_focus + Vector3(0.0, h, back)
	cam.look_at(_cam_focus + Vector3(0.0, 0.0, -3.0), Vector3.UP)


# =====================================================================
#  GAME FLOW
# =====================================================================
func _set_active(a: bool) -> void:
	player.active = a
	for o in opponents:
		o.active = a
	keeper_red.active = a
	keeper_blue.active = a


func _start_kickoff() -> void:
	state = State.COUNTDOWN
	state_timer = 2.0
	ball.reset_to(Vector3(0.0, 0.45, 0.0))
	_ball_prev_z = 0.0
	_out_timer = 0.0
	player.reset_to(Vector3(0.0, 0.0, 6.0), Vector3(0.0, 0.0, -1.0))
	for o in opponents:
		o.reset_to(o.home, Vector3(0.0, 0.0, 1.0))
		o.is_chaser = false
	keeper_red.reset_to(Vector3(0.0, 0.0, -48.8), Vector3(0.0, 0.0, 1.0))
	keeper_blue.reset_to(Vector3(0.0, 0.0, 48.8), Vector3(0.0, 0.0, -1.0))
	keeper_red.dive_t = 0.0
	keeper_blue.dive_t = 0.0
	_set_active(false)
	hud.set_score(score_blue, score_red)
	_update_clock()
	hud.show_message("KICK OFF", 1.8)
	_cam_focus = player.global_position


func _physics_process(delta: float) -> void:
	if ball == null:
		return
	match state:
		State.COUNTDOWN:
			state_timer -= delta
			if state_timer <= 0.0:
				state = State.PLAYING
				_set_active(true)
				_pick_chaser()
				hud.show_message("GO!", 0.7)
		State.PLAYING:
			_update_playing(delta)
		State.GOAL:
			state_timer -= delta
			if state_timer <= 0.0:
				_start_kickoff()
		State.FULLTIME:
			pass
	_ball_prev_z = ball.global_position.z


func _update_playing(delta: float) -> void:
	time_left -= delta
	if time_left <= 0.0:
		time_left = 0.0
		_update_clock()
		_end_match()
		return
	_update_clock()

	_chaser_timer -= delta
	if _chaser_timer <= 0.0:
		_chaser_timer = 0.2
		_pick_chaser()

	_check_goal()
	if state == State.PLAYING:
		_check_out_of_play(delta)


func _pick_chaser() -> void:
	var best = null
	var best_d := 1.0e9
	for o in opponents:
		var d: float = o.global_position.distance_to(ball.global_position)
		if d < best_d:
			best_d = d
			best = o
	for o in opponents:
		o.is_chaser = (o == best)


func _check_goal() -> void:
	var p := ball.global_position
	var limit := HALF_Z + 0.4
	if absf(p.x) < GOAL_HALF - 0.45 and p.y < GOAL_H - 0.4:
		if _ball_prev_z > -limit and p.z <= -limit:
			_score(true)
		elif _ball_prev_z < limit and p.z >= limit:
			_score(false)


func _score(blue_scored: bool) -> void:
	if blue_scored:
		score_blue += 1
	else:
		score_red += 1
	state = State.GOAL
	state_timer = 3.0
	_set_active(false)
	hud.set_score(score_blue, score_red)
	var who := TEAM_BLUE if blue_scored else TEAM_RED
	hud.show_message("GOAL!\n%s" % who, 2.8)


func _check_out_of_play(delta: float) -> void:
	var p := ball.global_position
	var out := absf(p.x) > HALF_X + 0.4 or absf(p.z) > HALF_Z + 0.4
	if out:
		_out_timer += delta
		if _out_timer > 0.9:
			_out_timer = 0.0
			ball.reset_to(Vector3(clampf(p.x, -26.0, 26.0), 0.45, clampf(p.z, -44.0, 44.0)))
			hud.show_message("BALL OUT", 0.8)
	else:
		_out_timer = 0.0


func _update_clock() -> void:
	var elapsed := 1.0 - time_left / match_length
	var game_sec := int(elapsed * 5400.0)
	hud.set_time("%02d:%02d" % [floori(game_sec / 60.0), game_sec % 60])


func _end_match() -> void:
	state = State.FULLTIME
	_set_active(false)
	controls.reset()
	hud.show_fulltime(score_blue, score_red)


# =====================================================================
#  PAUSE / NAVIGATION
# =====================================================================
func _on_pause() -> void:
	if state == State.FULLTIME:
		return
	get_tree().paused = true
	hud.show_pause(true)


func _on_resume() -> void:
	get_tree().paused = false
	hud.show_pause(false)
	controls.reset()


func _on_restart() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


func _on_menu() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if get_tree().paused:
			_on_resume()
		else:
			_on_pause()
	elif what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		if hud != null and not get_tree().paused:
			_on_pause()
