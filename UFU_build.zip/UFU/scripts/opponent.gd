extends "res://scripts/athlete.gd"
## Simple outfield AI: the nearest player chases the ball and drives at goal,
## everyone else holds a formation position that drifts toward the ball.

var ball: RigidBody3D
var home := Vector3.ZERO
var top_speed := 6.2
var shot_power := 1.0
var is_chaser := false
var shoot_cd := 0.0

const ATTACK_GOAL_Z := 50.0   # opponents attack the +Z goal


func setup(shirt: Color, skin: Color, home_pos: Vector3, speed: float, power: float) -> void:
	build_body(shirt, Color(0.95, 0.95, 0.95), skin)
	home = home_pos
	top_speed = speed
	shot_power = power


func _physics_process(delta: float) -> void:
	touch_cd = maxf(0.0, touch_cd - delta)
	shoot_cd = maxf(0.0, shoot_cd - delta)
	var hv := Vector3(velocity.x, 0.0, velocity.z)
	var desired := Vector3.ZERO

	if active and ball != null:
		var bp := ball.global_position
		var to_ball := Vector3(bp.x - global_position.x, 0.0, bp.z - global_position.z)
		var dist := to_ball.length()
		if is_chaser:
			if dist < 1.5:
				var to_goal := Vector3(0.0, 0.0, ATTACK_GOAL_Z) - Vector3(global_position.x, 0.0, global_position.z)
				var drive := to_goal.normalized() + to_ball.normalized() * 0.6
				desired = drive.normalized() * top_speed
			else:
				var bv := ball.linear_velocity
				var pred := bp + Vector3(bv.x, 0.0, bv.z) * 0.25
				var d := pred - global_position
				d.y = 0.0
				desired = d.normalized() * top_speed
		else:
			var hold := Vector3(clampf(home.x + bp.x * 0.3, -28.0, 28.0), 0.0, home.z + bp.z * 0.25)
			var d2 := hold - global_position
			d2.y = 0.0
			if d2.length() > 0.6:
				desired = d2.normalized() * minf(top_speed * 0.8, d2.length() * 2.0)

		# ball contact: shoot near goal, otherwise tap it ahead
		if dist < 1.0 and bp.y < 0.9 and touch_cd <= 0.0:
			var goal_dist := absf(ATTACK_GOAL_Z - global_position.z)
			if is_chaser and goal_dist < 26.0 and shoot_cd <= 0.0:
				var tx := randf_range(-3.0, 3.0)
				var dir := Vector3(tx - bp.x, 0.0, ATTACK_GOAL_Z - bp.z).normalized()
				var spd := randf_range(17.0, 23.0) * shot_power
				ball.linear_velocity = dir * spd + Vector3(0.0, randf_range(0.5, 3.0), 0.0)
				shoot_cd = 2.0
				touch_cd = 0.4
				kick_anim = 0.25
			elif hv.length() > 0.8:
				var fdir := hv.normalized()
				var push := hv.length() * 1.15 + 1.5
				var bv2 := ball.linear_velocity
				var along := Vector3(bv2.x, 0.0, bv2.z).dot(fdir)
				if along < push:
					ball.linear_velocity = Vector3(fdir.x * push, bv2.y, fdir.z * push)
					touch_cd = 0.18

	hv = hv.move_toward(desired, 22.0 * delta)
	velocity.x = hv.x
	velocity.z = hv.z
	if hv.length() > 0.6:
		steer_facing(hv, delta)
	move_athlete(delta)
	animate(delta, hv.length())
