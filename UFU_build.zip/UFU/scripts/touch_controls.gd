extends Control
## Android touch controls: floating joystick (left half), SPRINT / PASS / SHOOT buttons (right).
## Also supports keyboard in the editor: WASD/arrows, Shift = sprint, J = pass, K = shoot.

var charge_display := 0.0
var stamina_display := 1.0

const JOY_RADIUS := 95.0

var _touch_move := Vector2.ZERO
var _kb_move := Vector2.ZERO
var _joy_id := -1
var _joy_center := Vector2.ZERO
var _joy_pos := Vector2.ZERO
var _btn_touch := {}          # touch index -> button name
var _sprint_touch := false
var _shoot_touch := false
var _pass_time := -10000
var _prev_pass_key := false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


# ---------- public API used by the player ----------
func get_move() -> Vector2:
	if _touch_move.length() > 0.01:
		return _touch_move
	return _kb_move


func is_sprinting() -> bool:
	return _sprint_touch or Input.is_physical_key_pressed(KEY_SHIFT)


func is_shoot_held() -> bool:
	return _shoot_touch or Input.is_physical_key_pressed(KEY_K)


func consume_pass() -> bool:
	var ok := Time.get_ticks_msec() - _pass_time < 250
	_pass_time = -10000
	return ok


func reset() -> void:
	_touch_move = Vector2.ZERO
	_joy_id = -1
	_btn_touch.clear()
	_sprint_touch = false
	_shoot_touch = false
	_pass_time = -10000


# ---------- layout ----------
func _btn_defs() -> Dictionary:
	var s := get_viewport_rect().size
	return {
		"shoot": {"c": Vector2(s.x - 130.0, s.y - 130.0), "r": 72.0, "t": "SHOOT", "col": Color(1.0, 0.4, 0.2)},
		"pass": {"c": Vector2(s.x - 285.0, s.y - 85.0), "r": 56.0, "t": "PASS", "col": Color(0.3, 0.65, 1.0)},
		"sprint": {"c": Vector2(s.x - 255.0, s.y - 220.0), "r": 56.0, "t": "SPRINT", "col": Color(1.0, 0.85, 0.2)},
	}


# ---------- input ----------
func _input(event: InputEvent) -> void:
	var t := event as InputEventScreenTouch
	if t != null:
		if t.pressed:
			_on_press(t.index, t.position)
		else:
			_on_release(t.index)
		return
	var d := event as InputEventScreenDrag
	if d != null and d.index == _joy_id:
		_update_joy(d.position)


func _on_press(index: int, pos: Vector2) -> void:
	var defs := _btn_defs()
	for bn in defs:
		var info: Dictionary = defs[bn]
		var c: Vector2 = info["c"]
		var r: float = info["r"]
		if pos.distance_to(c) <= r * 1.2:
			_btn_touch[index] = bn
			if bn == "sprint":
				_sprint_touch = true
			elif bn == "shoot":
				_shoot_touch = true
			elif bn == "pass":
				_pass_time = Time.get_ticks_msec()
			return
	if _joy_id == -1 and pos.x < get_viewport_rect().size.x * 0.5:
		_joy_id = index
		_joy_center = pos
		_joy_pos = pos
		_touch_move = Vector2.ZERO


func _on_release(index: int) -> void:
	if index == _joy_id:
		_joy_id = -1
		_touch_move = Vector2.ZERO
	elif _btn_touch.has(index):
		var bn: String = _btn_touch[index]
		_btn_touch.erase(index)
		if bn == "sprint":
			_sprint_touch = false
		elif bn == "shoot":
			_shoot_touch = false


func _update_joy(pos: Vector2) -> void:
	var off := pos - _joy_center
	if off.length() > JOY_RADIUS:
		# drag the base along so the stick never gets stuck far away
		_joy_center += off.normalized() * (off.length() - JOY_RADIUS)
		off = pos - _joy_center
	_joy_pos = _joy_center + off
	var v := off / JOY_RADIUS
	_touch_move = v if v.length() > 0.12 else Vector2.ZERO


func _process(_delta: float) -> void:
	var kx := 0.0
	var ky := 0.0
	if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):
		kx -= 1.0
	if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
		kx += 1.0
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP):
		ky -= 1.0
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):
		ky += 1.0
	_kb_move = Vector2(kx, ky).normalized() if (kx != 0.0 or ky != 0.0) else Vector2.ZERO

	var pk := Input.is_physical_key_pressed(KEY_J)
	if pk and not _prev_pass_key:
		_pass_time = Time.get_ticks_msec()
	_prev_pass_key = pk
	queue_redraw()


# ---------- drawing ----------
func _draw() -> void:
	var s := get_viewport_rect().size
	var font := ThemeDB.fallback_font

	if _joy_id != -1:
		draw_circle(_joy_center, JOY_RADIUS, Color(1, 1, 1, 0.10))
		draw_arc(_joy_center, JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.45), 3.0)
		draw_circle(_joy_pos, 42.0, Color(1, 1, 1, 0.40))
	else:
		var hint := Vector2(190.0, s.y - 150.0)
		draw_arc(hint, JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.22), 3.0)
		draw_circle(hint, 36.0, Color(1, 1, 1, 0.15))

	var defs := _btn_defs()
	var held := _btn_touch.values()
	for bn in defs:
		var info: Dictionary = defs[bn]
		var c: Vector2 = info["c"]
		var r: float = info["r"]
		var col: Color = info["col"]
		var down := held.has(bn)
		col.a = 0.70 if down else 0.38
		draw_circle(c, r, col)
		draw_arc(c, r, 0.0, TAU, 40, Color(1, 1, 1, 0.8), 3.0)
		draw_string(font, c + Vector2(-r, 8.0), String(info["t"]), HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 22, Color.WHITE)
		if bn == "shoot" and charge_display > 0.01:
			draw_arc(c, r + 9.0, -PI / 2.0, -PI / 2.0 + TAU * charge_display, 32, Color(1, 1, 0.3, 0.95), 7.0)
		if bn == "sprint":
			var sc := Color(0.4, 1.0, 0.5, 0.9) if stamina_display > 0.3 else Color(1.0, 0.3, 0.2, 0.9)
			draw_arc(c, r + 9.0, -PI / 2.0, -PI / 2.0 + TAU * stamina_display, 32, sc, 6.0)
