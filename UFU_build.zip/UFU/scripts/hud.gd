extends CanvasLayer
## HUD: scoreboard, clock, messages, pause menu and full-time screen. Built in code.

signal pause_pressed
signal resume_pressed
signal restart_pressed
signal menu_pressed

const TEAM_BLUE := "NOVA"
const TEAM_RED := "EMBER"

var _score_label: Label
var _time_label: Label
var _msg_label: Label
var _info_label: Label
var _pause_btn: Button
var _pause_overlay: Control
var _end_overlay: Control
var _end_score: Label
var _end_result: Label
var _msg_timer := 0.0
var _fps_timer := 0.0


func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS

	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	# scoreboard
	var top := HBoxContainer.new()
	top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	top.offset_top = 10.0
	top.alignment = BoxContainer.ALIGNMENT_CENTER
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(top)

	var panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.07, 0.15, 0.85)
	sb.set_corner_radius_all(12)
	sb.content_margin_left = 22.0
	sb.content_margin_right = 22.0
	sb.content_margin_top = 6.0
	sb.content_margin_bottom = 6.0
	panel.add_theme_stylebox_override("panel", sb)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(panel)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 0)
	panel.add_child(vb)

	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 18)
	vb.add_child(row)
	row.add_child(_label(TEAM_BLUE, 26, Color(0.45, 0.7, 1.0)))
	_score_label = _label("0 - 0", 38, Color.WHITE)
	row.add_child(_score_label)
	row.add_child(_label(TEAM_RED, 26, Color(1.0, 0.5, 0.4)))

	_time_label = _label("00:00", 22, Color(1.0, 0.9, 0.4))
	_time_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_time_label)

	# info (mode / fps) top-left
	_info_label = _label("", 18, Color(1, 1, 1, 0.85))
	_info_label.position = Vector2(14, 10)
	root.add_child(_info_label)

	# pause button top-right
	_pause_btn = Game.make_button("II", Vector2(72, 60), 28)
	_pause_btn.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	_pause_btn.offset_left -= 16.0
	_pause_btn.offset_right -= 16.0
	_pause_btn.offset_top += 10.0
	_pause_btn.offset_bottom += 10.0
	_pause_btn.pressed.connect(func() -> void: pause_pressed.emit())
	root.add_child(_pause_btn)

	# center message
	_msg_label = _label("", 64, Color.WHITE)
	_msg_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_msg_label.offset_bottom = -220.0
	_msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_msg_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_msg_label.add_theme_constant_override("outline_size", 12)
	_msg_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_msg_label)

	# pause overlay
	_pause_overlay = _make_overlay(root, "PAUSED")
	var pv: VBoxContainer = _pause_overlay.get_node("C/V")
	var b1 := Game.make_button("RESUME")
	b1.pressed.connect(func() -> void: resume_pressed.emit())
	pv.add_child(b1)
	var b2 := Game.make_button("RESTART")
	b2.pressed.connect(func() -> void: restart_pressed.emit())
	pv.add_child(b2)
	var b3 := Game.make_button("MAIN MENU")
	b3.pressed.connect(func() -> void: menu_pressed.emit())
	pv.add_child(b3)

	# end overlay
	_end_overlay = _make_overlay(root, "FULL TIME")
	var ev: VBoxContainer = _end_overlay.get_node("C/V")
	_end_score = _label("", 48, Color.WHITE)
	_end_score.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ev.add_child(_end_score)
	_end_result = _label("", 40, Color(1.0, 0.9, 0.4))
	_end_result.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ev.add_child(_end_result)
	var e1 := Game.make_button("PLAY AGAIN")
	e1.pressed.connect(func() -> void: restart_pressed.emit())
	ev.add_child(e1)
	var e2 := Game.make_button("MAIN MENU")
	e2.pressed.connect(func() -> void: menu_pressed.emit())
	ev.add_child(e2)

	_update_info()


func _label(text: String, font_size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 5)
	return l


func _make_overlay(root: Control, title: String) -> Control:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.65)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	dim.visible = false
	root.add_child(dim)
	var center := CenterContainer.new()
	center.name = "C"
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.add_child(center)
	var v := VBoxContainer.new()
	v.name = "V"
	v.add_theme_constant_override("separation", 14)
	center.add_child(v)
	var t := _label(title, 56, Color.WHITE)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(t)
	return dim


func _update_info() -> void:
	var fps := Engine.get_frames_per_second()
	if Game.mode == "training":
		_info_label.text = "TRAINING   %d fps" % fps
	else:
		_info_label.text = "MATCH - %s   %d fps" % [Game.DIFFICULTY_NAMES[Game.difficulty], fps]


func _process(delta: float) -> void:
	if _msg_timer > 0.0:
		_msg_timer -= delta
		if _msg_timer <= 0.0:
			_msg_label.text = ""
	_fps_timer -= delta
	if _fps_timer <= 0.0:
		_fps_timer = 0.5
		_update_info()


func set_score(blue: int, red: int) -> void:
	_score_label.text = "%d - %d" % [blue, red]


func set_time(text: String) -> void:
	_time_label.text = text


func show_message(text: String, duration: float) -> void:
	_msg_label.text = text
	_msg_timer = duration


func show_pause(v: bool) -> void:
	_pause_overlay.visible = v


func show_fulltime(blue: int, red: int) -> void:
	_msg_label.text = ""
	_end_score.text = "%s  %d - %d  %s" % [TEAM_BLUE, blue, red, TEAM_RED]
	if blue > red:
		_end_result.text = "YOU WIN!"
	elif red > blue:
		_end_result.text = "YOU LOSE"
	else:
		_end_result.text = "DRAW"
	_pause_btn.visible = false
	_end_overlay.visible = true
