extends Node
## Autoload "Game": settings, shared state and UI helpers.

const SAVE_PATH := "user://ufu_settings.cfg"
const DIFFICULTY_NAMES := ["Easy", "Normal", "Hard"]
const ZOOM_NAMES := ["Near", "Normal", "Far"]
const LENGTH_OPTIONS := [2, 3, 5]

var mode := "match"        # "match" or "training"
var difficulty := 1        # 0 Easy, 1 Normal, 2 Hard
var match_minutes := 3     # real minutes for a 90 minute match
var camera_zoom := 1       # 0 Near, 1 Normal, 2 Far


func _ready() -> void:
	load_settings()


func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("game", "difficulty", difficulty)
	cfg.set_value("game", "match_minutes", match_minutes)
	cfg.set_value("game", "camera_zoom", camera_zoom)
	cfg.save(SAVE_PATH)


func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	difficulty = clampi(int(cfg.get_value("game", "difficulty", 1)), 0, 2)
	match_minutes = int(cfg.get_value("game", "match_minutes", 3))
	if not LENGTH_OPTIONS.has(match_minutes):
		match_minutes = 3
	camera_zoom = clampi(int(cfg.get_value("game", "camera_zoom", 1)), 0, 2)


func make_button(text: String, min_size := Vector2(340, 68), font_size := 30) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.add_theme_font_size_override("font_size", font_size)
	b.add_theme_stylebox_override("normal", _box(Color(0.10, 0.45, 0.25, 0.95)))
	b.add_theme_stylebox_override("hover", _box(Color(0.14, 0.58, 0.32, 1.0)))
	b.add_theme_stylebox_override("pressed", _box(Color(0.06, 0.30, 0.16, 1.0)))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color.WHITE)
	return b


func _box(c: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(14)
	s.border_color = Color(1, 1, 1, 0.35)
	s.set_border_width_all(2)
	return s
