extends "res://scripts/athlete.gd"
## The human-controlled player: movement, stamina, dribble, pass and shoot.

const ControlsScript = preload("res://scripts/touch_controls.gd")

const JOG_SPEED := 6.8
const SPRINT_SPEED := 9.6
const ACCEL := 28.0
const DECEL := 36.0
const KICK_RANGE := 1.8

var controls: ControlsScript
var ball: RigidBody3D
var stamina := 1.0
var exhausted := false
var shoot_charge := 0.0
var charging := false


func setup() -> void:
	build_body(Color(0.12, 0.42, 0.95), Color(1, 1, 1), Color(0.87, 0.68, 0.52))


func _physics_process(delta: float) -> void:
	touch_cd = maxf(0.0, touch_cd - delta)
	var hv := Vector3(velocity.x, 0.0, velocity.z)
	var move_in := Vector2.ZERO
	var want_sprint := false
	if active and controls != null:
		move_in = controls.get_move()
		want_sprint = controls.is_sprinting()

	# stamina
	var sprinting := false
	if want_sprint and move_in.length() > 0.3 and not exhausted:
		sprinting = true
		stamina = maxf(0.0, stamina - 0.22 * delta)
		if stamina <= 0.0:
			exhausted = true
	else:
		stamina = minf(1.0, stamina + 0.12 * delta)
		if exhausted and stamina > 0.3:
			exhausted = false

	var top_speed := SPRINT_SPEED if sprinting else JOG_SPEED
	var target := Vector3(move_in.x, 0.0, move_in.y) * top_speed
	if target.length() > top_speed:
		target = target.normalized() * top_speed
	var rate := ACCEL if target.length() > hv.length() else DECEL
	hv = hv.move_toward(target, rate * delta)
	velocity.x = hv.x
	velocity.z = hv.z
	if hv.length() > 0.6:
		steer_facing(hv, delta)

	if active and ball != null and controls != null:
		_ball_actions(delta, hv, move_in)

	move_athlete(delta)
	animate(delta, hv.length())

	if controls != null:
		controls.charge_display = shoot_charge
		controls.stamina_display = stamina


func _ball_actions(delta: float, hv: Vector3, move_in: Vector2) -> void:
	var bp := ball.global_position
	var flat := Vector3(bp.x - global_position.x, 0.0, bp.z - global_position.z)
	var dist := flat.length()
	var aim := facing
	if move_in.length() > 0.25:
		aim = Vector3(move_in.x, 0.0, move_in.y).normalized()

	# PASS (tap)
	if controls.consume_pass():
		if dist < KICK_RANGE and bp.y < 1.4:
			_kick(aim, 15.0, 0.0)

	# SHOOT (hold to charge, release to kick)
	if controls.is_shoot_held():
		charging = true
		shoot_charge = minf(1.0, shoot_charge + delta / 0.8)
	elif charging:
		if dist < KICK_RANGE and bp.y < 1.4:
			_shoot(aim, shoot_charge, bp)
		charging = false
		shoot_charge = 0.0

	# DRIBBLE: running into the ball taps it ahead
	if touch_cd <= 0.0 and dist < 1.05 and bp.y < 0.9 and hv.length() > 1.0:
		var dir := hv.normalized()
		var in_front := dist < 0.7 or flat.normalized().dot(dir) > 0.35
		if in_front:
			var push := hv.length() * 1.18 + 1.6
			var bv := ball.linear_velocity
			var along := Vector3(bv.x, 0.0, bv.z).dot(dir)
			if along < push:
				ball.linear_velocity = Vector3(dir.x * push, bv.y, dir.z * push)
				touch_cd = 0.16


func _kick(dir: Vector3, speed: float, up: float) -> void:
	ball.linear_velocity = dir * speed + Vector3(0.0, up, 0.0)
	kick_anim = 0.25
	touch_cd = 0.35


func _shoot(aim: Vector3, charge: float, bp: Vector3) -> void:
	var d := aim
	# light aim assist: if aiming roughly at the goal, bend toward where the aim line meets the goal
	if aim.z < -0.2:
		var t := (-50.0 - bp.z) / aim.z
		if t > 0.0 and t < 55.0:
			var ix := bp.x + aim.x * t
			if absf(ix) < 8.0:
				var tx := clampf(ix, -3.0, 3.0)
				d = Vector3(tx - bp.x, 0.0, -50.0 - bp.z).normalized()
	var speed := lerpf(13.0, 31.0, charge)
	var up := 1.0 + 4.5 * charge
	_kick(d, speed, up)
