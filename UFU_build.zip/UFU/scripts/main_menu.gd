extends Control
## Main menu: Play, Training, Settings. Whole UI is built in code.

var _main_box: VBoxContainer
var _settings_box: VBoxContainer
var _diff_btn: Button
var _length_btn: Button
var _cam_btn: Button


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	resized.connect(queue_redraw)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 12)
	center.add_child(stack)

	var title := _label("ULTIMATE FOOTBALL UNIVERSE", 46)
	stack.add_child(title)
	var sub := _label("UFU  -  First Playable", 24)
	sub.add_theme_color_override("font_color", Color(1.0, 0.9, 0.4))
	stack.add_child(sub)
	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 14)
	stack.add_child(gap)

	# --- main buttons ---
	_main_box = VBoxContainer.new()
	_main_box.add_theme_constant_override("separation", 12)
	_main_box.alignment = BoxContainer.ALIGNMENT_CENTER
	stack.add_child(_main_box)

	var play := Game.make_button("PLAY MATCH")
	play.pressed.connect(_on_play)
	_main_box.add_child(play)
	var train := Game.make_button("TRAINING")
	train.pressed.connect(_on_training)
	_main_box.add_child(train)
	var sett := Game.make_button("SETTINGS")
	sett.pressed.connect(_show_settings.bind(true))
	_main_box.add_child(sett)
	var quit := Game.make_button("QUIT")
	quit.pressed.connect(get_tree().quit)
	_main_box.add_child(quit)

	# --- settings ---
	_settings_box = VBoxContainer.new()
	_settings_box.add_theme_constant_override("separation", 12)
	_settings_box.alignment = BoxContainer.ALIGNMENT_CENTER
	_settings_box.visible = false
	stack.add_child(_settings_box)

	_diff_btn = Game.make_button("")
	_diff_btn.pressed.connect(_cycle_difficulty)
	_settings_box.add_child(_diff_btn)
	_length_btn = Game.make_button("")
	_length_btn.pressed.connect(_cycle_length)
	_settings_box.add_child(_length_btn)
	_cam_btn = Game.make_button("")
	_cam_btn.pressed.connect(_cycle_camera)
	_settings_box.add_child(_cam_btn)
	var back := Game.make_button("BACK")
	back.pressed.connect(_show_settings.bind(false))
	_settings_box.add_child(back)
	_refresh_settings_text()


func _label(text: String, size: int) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", Color.WHITE)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	return l


func _draw() -> void:
	var s := size
	draw_rect(Rect2(Vector2.ZERO, s), Color(0.04, 0.22, 0.12))
	var stripe := s.x / 12.0
	for i in range(12):
		if i % 2 == 0:
			draw_rect(Rect2(float(i) * stripe, 0.0, stripe, s.y), Color(0.05, 0.27, 0.14))
	var c := s * 0.5
	draw_arc(c, s.y * 0.38, 0.0, TAU, 64, Color(1, 1, 1, 0.12), 4.0)
	draw_line(Vector2(c.x, 0.0), Vector2(c.x, s.y), Color(1, 1, 1, 0.12), 4.0)


func _on_play() -> void:
	Game.mode = "match"
	get_tree().change_scene_to_file("res://scenes/match.tscn")


func _on_training() -> void:
	Game.mode = "training"
	get_tree().change_scene_to_file("res://scenes/match.tscn")


func _show_settings(v: bool) -> void:
	_settings_box.visible = v
	_main_box.visible = not v
	_refresh_settings_text()


func _cycle_difficulty() -> void:
	Game.difficulty = (Game.difficulty + 1) % 3
	Game.save_settings()
	_refresh_settings_text()


func _cycle_length() -> void:
	var i: int = Game.LENGTH_OPTIONS.find(Game.match_minutes)
	Game.match_minutes = int(Game.LENGTH_OPTIONS[(i + 1) % Game.LENGTH_OPTIONS.size()])
	Game.save_settings()
	_refresh_settings_text()


func _cycle_camera() -> void:
	Game.camera_zoom = (Game.camera_zoom + 1) % 3
	Game.save_settings()
	_refresh_settings_text()


func _refresh_settings_text() -> void:
	_diff_btn.text = "Difficulty: %s" % Game.DIFFICULTY_NAMES[Game.difficulty]
	_length_btn.text = "Match length: %d min" % Game.match_minutes
	_cam_btn.text = "Camera: %s" % Game.ZOOM_NAMES[Game.camera_zoom]


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if _settings_box != null and _settings_box.visible:
			_show_settings(false)
		else:
			get_tree().quit()
